# The College Finder - Python Tool
# Created by Divyansh Rana (SAP ID: 500121856, Roll No: R2142230746)

def get_college_recommendations(board_marks, jee_score):
    # Sample college database with cutoffs
    colleges = [
        {"name": "IIT Delhi", "board_cutoff": 90, "jee_cutoff": 98},
        {"name": "NIT Trichy", "board_cutoff": 85, "jee_cutoff": 95},
        {"name": "IIIT Hyderabad", "board_cutoff": 80, "jee_cutoff": 92},
        {"name": "DTU Delhi", "board_cutoff": 75, "jee_cutoff": 85},
        {"name": "UPES Dehradun", "board_cutoff": 60, "jee_cutoff": 70},
        {"name": "Amity University", "board_cutoff": 55, "jee_cutoff": 60},
        {"name": "Local Govt College", "board_cutoff": 50, "jee_cutoff": 50}
    ]

    recommendations = []

    for college in colleges:
        if board_marks >= college["board_cutoff"] and jee_score >= college["jee_cutoff"]:
            recommendations.append(college["name"])

    return recommendations


def main():
    print("🎓 Welcome to The College Finder")
    print("----------------------------------")
    
    try:
        board_marks = float(input("Enter your Board Percentage (e.g., 87.5): "))
        jee_score = float(input("Enter your JEE Mains Percentile (e.g., 93.2): "))

        recommended_colleges = get_college_recommendations(board_marks, jee_score)

        print("\n✅ Based on your scores, you may qualify for the following colleges:")
        if recommended_colleges:
            for idx, college in enumerate(recommended_colleges, start=1):
                print(f"{idx}. {college}")
        else:
            print("Sorry, no matches found. Please consider applying to private universities or reattempting.")

    except ValueError:
        print("Invalid input. Please enter valid numeric values for scores.")

if __name__ == "__main__":
    main()
